require 'jsonapi-serializers'

class UserSerializer
  include JSONAPI::Serializer

  attribute :fname
  attribute :id
  attribute :lname
  attribute :email
  attribute :auth_token
  friends = []
  attribute :friends do
  	object.friends.each do |friend |
  		friends.push({fname: friend.fname, lname: friend.lname, email: friend.email})
    end
    debugger
    friends
  end
end