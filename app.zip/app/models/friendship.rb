class Friendship
  include Mongoid::Document

end
